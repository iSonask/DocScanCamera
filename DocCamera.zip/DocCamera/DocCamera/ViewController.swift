//
//  ViewController.swift
//  DocCamera
//
//  Created by Akash S on 26/12/2022.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet private weak var cameraView: UIView!
    var controller: CameraScannerViewController!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setupView()
    }

    private func setupView() {

        controller = CameraScannerViewController()
        controller.isAutoScanEnabled = true
        controller.view.frame = cameraView.bounds
        controller.willMove(toParent: self)
        
        cameraView.addSubview(controller.view)
        self.addChild(controller)
        controller.didMove(toParent: self)
        controller.delegate = self
        
    }
    
    @IBAction func capture(_ sender: UIButton) {
        controller.capture()
    }
    
    @IBAction func flash(_ sender: UIButton) {
        controller.toggleFlash()
    }
    
    @IBAction func toggleAutoScann(_ sender: UIButton) {
        controller.toggleAutoScan()
    }
    
    @IBAction func toggleAutoZoom(_ sender: UIButton) {
        controller.toggleAutoZoom()
    }
}


extension ViewController: CameraScannerViewOutputDelegate {
    
    func captureImageFailWithError(error: Error) {
        print(error)
    }

    func captureImageSuccess(image: UIImage, withQuad quad: Quadrilateral?) {
        print(quad)
        print(image)
//        guard let controller = self.storyboard?.instantiateViewController(withIdentifier: "NewEditImageView") as? EditImageViewController
//            else { return }
//        controller.modalPresentationStyle = .fullScreen
//        controller.captureImage = image
//        controller.quad = quad
//        navigationController?.pushViewController(controller, animated: false)
    }
}
